
import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "@/auth/AuthContext";
export function RouteGuard() {
  const { isAuthenticated } = useAuth();
  console.log("RouteGuard – isAuthenticated:", isAuthenticated);

  return isAuthenticated ? <Outlet /> : <Navigate to="/login" replace />;
}
